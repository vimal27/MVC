﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace NewApplication
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/angularJS").Include(
                     "~/Scripts/angular.js",
                     "~/Scripts/JSControllers/Module.js"));
            bundles.Add(new ScriptBundle("~/bundles/usersJS").Include(
                     "~/Scripts/JSControllers/usersService.js",
                     "~/Scripts/JSControllers/usersController.js"));
            bundles.Add(new ScriptBundle("~/bundles/teamsJS").Include(
                     "~/Scripts/JSControllers/teamsService.js",
                     "~/Scripts/JSControllers/teamsController.js"));
            bundles.Add(new ScriptBundle("~/bundles/mastersJS").Include("~/Content/bower_components/jquery/dist/jquery.js",
                    "~/Content/bower_components/bootstrap/dist/js/bootstrap.js",
                    "~/Content/js/angular.js",
                    "~/Content/js/angular-route.js",
                    "~/Content/js/sweetalert.js",
                    "~/Content/clockpicker/js/bootstrap-clockpicker.js",
                    "~/Content/percentageindicator/js/jquery.classyloader.js",
                    "~/Content/bower_components/bootstrap-switch/dist/js/bootstrap-switch.js",
                    "~/Content/bower_components/matchHeight/jquery.matchHeight.js",
                    "~/Content/bower_components/select2/dist/js/select2.full.js",
                    "~/Content/vendor/js/ace/ace.js",
                    "~/Content/vendor/js/ace/mode-html.js",
                    "~/Content/vendor/js/ace/theme-github.js",
                    "~/Content/js/app.js",
                    "~/Content/bower_components/DataTables/media/js/jquery.dataTables.js",
                    "~/Content/vendor/js/dataTables.bootstrap.js",
                    "~/Content/js/application.js",
                    "~/Content/js/bootbox.js",
                    "~/Content/amcharts/amcharts.js",
                    "~/Content/amcharts/serial.js",
                    "~/Content/amcharts/gauge.js",
                    "~/Content/amcharts/light.js"));
            bundles.Add(new StyleBundle("~/bundles/mastersCSS").Include("~/Content/bower_components/bootstrap/dist/css/bootstrap.css",
                    "~/Content/clockpicker/css/bootstrap-clockpicker.css",
                    "~/Content/clockpicker/css/github.css",
                    "~/Content/bower_components/fontawesome/css/font-awesome.css",
                    "~/Content/bower_components/animate.css/animate.css",
                    "~/Content/bower_components/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.css",
                    "~/Content/bower_components/iCheck/skins/flat/_all.css",
                    "~/Content/css/bootstrap-multiselect.css",
                    "~/Content/bower_components/DataTables/media/css/jquery.dataTables.css",
                    "~/Content/vendor/css/dataTables.bootstrap.css",
                    "~/Content/bower_components/select2/dist/css/select2.css",
                    "~/Content/css/style.css",
                    "~/Content/css/styleInline.css",
                    "~/Content/css/themes.css",
                    "~/Content/css/sweetalert.css",
                    "~/Content/bower_components/iCheck/icheck.js",
                    "~/Content/bower_components/jquery/dist/jquery.ganttView.js",
                    "~/Content/js/datetimepicker/jquery.simple-dtpicker.js",
                    "~/Content/bower_components/bootstrap/dist/js/bootstrap-multiselect.js",
                    "~/Content/js/charts/highcharts.js",
                    "~/Content/js/charts/exporting.js"));
        }
    }
}